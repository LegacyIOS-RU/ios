If you would like to translate IPA Installer, duplicate (one or more times depending on language variants) 
the "lang_en-us.txt" file and rename it to the one shown in this site (be sure to visit on your iPhone/iPad):

http://jsfiddle.net/bqLtjje5/

As an example this is what the file would be named for German localisation:

lang_de-de.txt

For French..
lang_fr-fr.txt  - French

Arabic.. etc..
lang_ar.txt  - Arabic



Chinese
zh-cn 	Mainland China, simplified characters
zh-tw 	Taiwan, traditional characters
zh-hk 	Hong Kong, traditional characters

Spanish:
es-es 	Castilian Spanish (as written and spoken in Northern Spain)
es-mx 	Mexican Spanish
es-ar 	Argentine Spanish
es-co 	Colombian Spanish

Portuguese 
pt-pt 	European Portuguese (as written and spoken in Portugal)
pt-br 	Brazilian Portuguese



you can find the list of ISO 639-1 codes at: http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes

